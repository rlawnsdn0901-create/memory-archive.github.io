// Lightweight client-side store for "기억" entries (records of works).
// Persists to localStorage so the user can revisit notes between sessions.

export type Memory = {
  id: string;
  title: string;
  body: string;
  category?: "movie" | "drama" | "novel";
  date: string; // ISO
  collectionId?: string;
  // 자동 보강된 작품 메타 (있을 때만 사용)
  originalTitle?: string;
  year?: string;
  description?: string; // 작품에 대한 짧은 설명 한 줄
  emotionTags?: string[];
};

export type Collection = {
  id: string;
  title: string;
  tag: string;
  excerpt: string;
  memoryIds: string[];
  samples?: SampleWork[];
  createdAt: string;
};

const MEM_KEY = "ql.memories.v1";
const COL_KEY = "ql.collections.v2";
const IMG_KEY = "ql.workImages.v1";

export type SampleWork = {
  title: string;
  line: string;
};

const seedCollections: (Collection & { samples?: SampleWork[] })[] = [
  {
    id: "rainy-films",
    title: "비 오는 날의 영화들",
    tag: "Movies",
    excerpt: "창밖의 빗소리와 함께 다시 보고 싶었던 장면들.",
    memoryIds: [],
    createdAt: new Date().toISOString(),
    samples: [
      { title: "노팅 힐", line: "비 오는 골목, 푸른 문 앞에서" },
      { title: "이터널 선샤인", line: "지워도 끝내 남는 마음" },
      { title: "그녀", line: "도시의 빗소리 같은 목소리" },
    ],
  },
  {
    id: "winter-lines",
    title: "겨울 밤에 읽은 문장",
    tag: "Novels",
    excerpt: "이불 속에서 밑줄 그었던 문장들.",
    memoryIds: [],
    createdAt: new Date().toISOString(),
    samples: [
      { title: "노르웨이의 숲", line: "겨울 도쿄, 흩어진 마음 한 장" },
      { title: "데미안", line: "알을 깨고 나오는 새처럼" },
      { title: "어린 왕자", line: "별 하나에 길들인 마음" },
    ],
  },
  {
    id: "lasting-faces",
    title: "오래 남은 인물들",
    tag: "Dramas",
    excerpt: "이름은 잊었지만 표정은 남아 있는 사람들.",
    memoryIds: [],
    createdAt: new Date().toISOString(),
    samples: [
      { title: "나의 아저씨", line: "아무것도 아닌, 모두인 사람" },
      { title: "비밀의 숲", line: "차가운 복도 끝의 표정" },
    ],
  },
  {
    id: "long-credits",
    title: "엔딩 크레딧이 길었던 작품",
    tag: "Movies",
    excerpt: "끝나도 자리에서 일어날 수 없었던 영화들.",
    memoryIds: [],
    createdAt: new Date().toISOString(),
    samples: [
      { title: "라라랜드", line: "음악이 멎을 때까지 앉아 있던 시간" },
      { title: "인터스텔라", line: "사랑은 시간을 건너간다" },
    ],
  },
];

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function loadMemories(): Memory[] {
  if (typeof window === "undefined") return [];
  return safeParse<Memory[]>(localStorage.getItem(MEM_KEY), []);
}

export function saveMemories(list: Memory[]) {
  localStorage.setItem(MEM_KEY, JSON.stringify(list));
  window.dispatchEvent(new CustomEvent("ql:memories-changed"));
}

export function addMemory(
  m: Omit<Memory, "id" | "date"> & { date?: string }
): Memory {
  const memory: Memory = {
    ...m,
    id: crypto.randomUUID(),
    date: m.date ?? new Date().toISOString(),
  };
  const list = [memory, ...loadMemories()];
  saveMemories(list);
  return memory;
}

/**
 * 같은 제목의 다른 기록에 메타 정보(원제/년도/설명/감정태그)를 보강.
 * 비어있는 필드만 채운다 — 사용자가 직접 적은 값은 덮어쓰지 않음.
 */
export function enrichMemoriesByTitle(
  title: string,
  meta: Pick<Memory, "originalTitle" | "year" | "description" | "emotionTags" | "category">
) {
  const t = title.trim().toLowerCase();
  const list = loadMemories().map((m) => {
    if (m.title.trim().toLowerCase() !== t) return m;
    return {
      ...m,
      originalTitle: m.originalTitle || meta.originalTitle,
      year: m.year || meta.year,
      description: m.description || meta.description,
      emotionTags: m.emotionTags && m.emotionTags.length > 0 ? m.emotionTags : meta.emotionTags,
      category: m.category || meta.category,
    };
  });
  saveMemories(list);
}

export function updateMemory(id: string, patch: Partial<Pick<Memory, "title" | "body" | "category">>) {
  const list = loadMemories().map((m) => (m.id === id ? { ...m, ...patch } : m));
  saveMemories(list);
}

export function deleteMemory(id: string) {
  const list = loadMemories().filter((m) => m.id !== id);
  saveMemories(list);
}

export function memoriesForTitle(title: string): Memory[] {
  const t = title.trim().toLowerCase();
  return loadMemories().filter((m) => m.title.trim().toLowerCase() === t);
}

export function loadCollections(): Collection[] {
  if (typeof window === "undefined") return seedCollections;
  const stored = safeParse<Collection[] | null>(localStorage.getItem(COL_KEY), null);
  if (!stored) {
    localStorage.setItem(COL_KEY, JSON.stringify(seedCollections));
    return seedCollections;
  }
  return stored;
}

export function saveCollections(list: Collection[]) {
  localStorage.setItem(COL_KEY, JSON.stringify(list));
  window.dispatchEvent(new CustomEvent("ql:collections-changed"));
}

export function addCollection(title: string, tag = "Notes"): Collection {
  const c: Collection = {
    id: crypto.randomUUID(),
    title,
    tag,
    excerpt: "",
    memoryIds: [],
    samples: [],
    createdAt: new Date().toISOString(),
  };
  saveCollections([...loadCollections(), c]);
  return c;
}

export function updateCollectionExcerpt(collectionId: string, excerpt: string) {
  const list = loadCollections().map((c) =>
    c.id === collectionId ? { ...c, excerpt } : c
  );
  saveCollections(list);
}

export function addWorkToCollection(collectionId: string, work: SampleWork) {
  const list = loadCollections().map((c) =>
    c.id === collectionId
      ? { ...c, samples: [...(c.samples ?? []), work] }
      : c
  );
  saveCollections(list);
}

export function updateWorkInCollection(collectionId: string, index: number, work: SampleWork) {
  const list = loadCollections().map((c) => {
    if (c.id !== collectionId) return c;
    const samples = [...(c.samples ?? [])];
    samples[index] = work;
    return { ...c, samples };
  });
  saveCollections(list);
}

export function removeWorkFromCollection(collectionId: string, index: number) {
  const list = loadCollections().map((c) => {
    if (c.id !== collectionId) return c;
    const samples = [...(c.samples ?? [])];
    samples.splice(index, 1);
    return { ...c, samples };
  });
  saveCollections(list);
}

// ===== 작품별 사진 (작품 제목 단위로 보관) =====
// 사진은 base64 dataURL로 저장한다. (브라우저 로컬에 가벼운 기록 보관용)

type WorkImagesMap = Record<string, string[]>; // key: 작품 제목 (소문자/trim)

const titleKey = (title: string) => title.trim().toLowerCase();

function loadAllImages(): WorkImagesMap {
  if (typeof window === "undefined") return {};
  return safeParse<WorkImagesMap>(localStorage.getItem(IMG_KEY), {});
}

function saveAllImages(map: WorkImagesMap) {
  localStorage.setItem(IMG_KEY, JSON.stringify(map));
  window.dispatchEvent(new CustomEvent("ql:work-images-changed"));
}

export function imagesForTitle(title: string): string[] {
  return loadAllImages()[titleKey(title)] ?? [];
}

export function addImageForTitle(title: string, dataUrl: string) {
  const map = loadAllImages();
  const k = titleKey(title);
  map[k] = [...(map[k] ?? []), dataUrl];
  saveAllImages(map);
}

export function removeImageForTitle(title: string, index: number) {
  const map = loadAllImages();
  const k = titleKey(title);
  const list = [...(map[k] ?? [])];
  list.splice(index, 1);
  map[k] = list;
  saveAllImages(map);
}
