export interface WorkResult {
  title: string;
  originalTitle?: string;
  category: "movie" | "drama" | "novel";
  year?: string;
  /** Long, atmospheric description for the search result view */
  description: string;
  /** Short one-line summary saved to the folder card */
  shortDescription?: string;
  emotionTags: string[];
  gentleLine: string;
}
