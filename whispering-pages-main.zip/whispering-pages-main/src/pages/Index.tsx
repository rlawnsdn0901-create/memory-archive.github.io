import { useState } from "react";
import GrainOverlay from "@/components/archive/GrainOverlay";
import InkCursor from "@/components/archive/InkCursor";
import Hero from "@/components/archive/Hero";
import FolderShelf from "@/components/archive/FolderShelf";
import Collections from "@/components/archive/Collections";
import RecordEntry from "@/components/archive/RecordEntry";
import Chapter from "@/components/archive/Chapter";
import PageTurnArrow from "@/components/archive/PageTurnArrow";
import type { WorkResult } from "@/types/work";

const Index = () => {
  const [prefilledWork, setPrefilledWork] = useState<WorkResult | undefined>();

  return (
    <>
      <GrainOverlay />
      <InkCursor />

      <main className="relative">
        {/* Chapter 001 — Hero & Search */}
        <section className="pt-12 md:pt-20">
          <Chapter number={1} title="조용히 문을 밀고 들어서다" />
          <Hero onStartRecord={(w) => setPrefilledWork(w)} />
        </section>

        {/* Chapter 002 — Folders */}
        <section className="border-t border-ink/5 pt-20">
          <Chapter number={2} title="서가 사이를 천천히 걷다" />
          <FolderShelf />
          <PageTurnArrow targetId="collections" label="다음 페이지를 펼치다" />
        </section>

        {/* Chapter 003 — Collections */}
        <section id="collections" className="border-t border-ink/5 pt-20">
          <Chapter number={3} title="기억을 묶어두다" />
          <Collections />
          <PageTurnArrow targetId="record" label="기록의 방으로 내려가다" />
        </section>

        {/* Chapter 004 — Record */}
        <section className="border-t border-ink/5 pt-20">
          <Chapter
            number={4}
            title="오늘을 남기다"
          />
          <RecordEntry prefilledWork={prefilledWork} />
        </section>

        <footer className="relative z-10 px-6 pb-16 pt-8 text-center">
          <p className="font-serif-soft text-xs italic tracking-widest text-ink-soft/60">
            © 2026 Archive of Memories. All echoes preserved.
          </p>
        </footer>
      </main>
    </>
  );
};

export default Index;
