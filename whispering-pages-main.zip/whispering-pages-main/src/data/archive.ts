export type Category = "movie" | "drama" | "novel";

export type ArchiveItem = {
  title: string;
  original?: string;
  year?: string;
  /** 작품에 대한 짧은 한 줄 설명 (객관적). */
  note: string;
  /** 내가 남긴 기록 — 명장면 · 명대사 · 감정 중심의 한 줄 (작품마다 모두 다르게). */
  record: string;
};

export const movies: ArchiveItem[] = [
  {
    title: "이터널 선샤인",
    original: "Eternal Sunshine of the Spotless Mind",
    year: "2004",
    note: "기억을 지운 두 사람이, 다시 마주치고 마는 사랑 이야기.",
    record: "기차 안에서 다시 마주친 눈빛이, 한참 동안 비켜나지 못했다.",
  },
  {
    title: "비포 선라이즈",
    original: "Before Sunrise",
    year: "1995",
    note: "낯선 도시에서 보낸 단 하룻밤의 대화로 이루어진 영화.",
    record: "\"내일이 없는 것처럼 이야기하자\"는 한마디가 오래 따라왔다.",
  },
  {
    title: "라라랜드",
    original: "La La Land",
    year: "2016",
    note: "꿈을 좇는 두 사람이 스쳐 지나는 LA의 음악 영화.",
    record: "마지막 피아노 앞에서, 서로를 향해 짧게 끄덕이던 그 순간.",
  },
  {
    title: "인셉션",
    original: "Inception",
    year: "2010",
    note: "꿈속의 꿈을 설계하는 사람들의 다층적 미스터리.",
    record: "팽이가 도는 동안, 숨을 참고 있었다는 걸 끝나고서야 알았다.",
  },
  {
    title: "인터스텔라",
    original: "Interstellar",
    year: "2014",
    note: "지구를 떠나 시간을 가로지르는 부녀의 이야기.",
    record: "딸의 영상 앞에서 흘리던 침묵이, 가장 큰 대사처럼 들렸다.",
  },
  {
    title: "그랜드 부다페스트 호텔",
    original: "The Grand Budapest Hotel",
    year: "2014",
    note: "사라져가는 유럽의 한 호텔을 둘러싼 우아한 코미디.",
    record: "분홍빛 케이크 상자 하나로, 한 시대가 살그머니 닫히는 기분.",
  },
  {
    title: "캐롤",
    original: "Carol",
    year: "2015",
    note: "1950년대 뉴욕, 두 여자가 천천히 가까워지는 이야기.",
    record: "어깨 위에 살짝 얹힌 손끝에서, 모든 말이 시작되고 멈췄다.",
  },
  {
    title: "그녀",
    original: "Her",
    year: "2013",
    note: "외로운 한 남자가 인공지능과 사랑에 빠지는 미래의 이야기.",
    record: "전화기 너머의 숨소리만으로도, 한 사람을 안고 있는 기분이 든 밤.",
  },
  {
    title: "노팅 힐",
    original: "Notting Hill",
    year: "1999",
    note: "런던 작은 서점 주인과 세계적 배우의 로맨틱 코미디.",
    record: "\"I'm just a girl…\"이라는 말이, 의외의 자리에서 마음을 흔들었다.",
  },
];

export const dramas: ArchiveItem[] = [
  {
    title: "나의 아저씨",
    original: "My Mister",
    year: "2018",
    note: "묵묵한 중년 남자와 거친 청년의 위로에 관한 드라마.",
    record: "지하철 계단을 같이 내려가던 뒷모습이, 어떤 위로보다 따뜻했다.",
  },
  {
    title: "비밀의 숲",
    original: "Stranger",
    year: "2017",
    note: "감정을 잃은 검사와 강력계 형사가 진실을 추적하는 수사극.",
    record: "감정을 잃었다던 사람이 가장 흔들리던 한 컷에서 멈춰 섰다.",
  },
  {
    title: "브레이킹 배드",
    original: "Breaking Bad",
    year: "2008",
    note: "평범한 화학 교사가 마약 제조자로 변해가는 미국 드라마.",
    record: "사막 한가운데, 모자를 눌러쓰고 돌아서던 장면이 오래 남았다.",
  },
  {
    title: "체르노빌",
    original: "Chernobyl",
    year: "2019",
    note: "1986년 원전 사고를 사실적으로 재현한 다큐드라마.",
    record: "\"진실의 대가는 무엇인가\"라는 첫 대사가, 끝까지 떨어지지 않았다.",
  },
  {
    title: "프렌즈",
    original: "Friends",
    year: "1994",
    note: "뉴욕에서 같이 늙어가는 여섯 친구의 일상 시트콤.",
    record: "소파 위 여섯 명의 웃음소리만으로, 외롭지 않게 지나간 저녁이 많다.",
  },
  {
    title: "이상한 변호사 우영우",
    original: "Extraordinary Attorney Woo",
    year: "2022",
    note: "자폐 스펙트럼 신입 변호사의 따뜻한 성장 드라마.",
    record: "회전문 앞에서 숨을 고르던 그 짧은 망설임이 마음에 박혔다.",
  },
  {
    title: "더 크라운",
    original: "The Crown",
    year: "2016",
    note: "엘리자베스 2세 여왕의 즉위와 통치를 다룬 시대극.",
    record: "왕관을 쓰기 직전, 거울 앞에서 잠시 흔들리던 눈빛.",
  },
  {
    title: "미스터 션샤인",
    original: "Mr. Sunshine",
    year: "2018",
    note: "구한말, 신미양요로 미국에 건너간 한 남자의 귀환 이야기.",
    record: "\"러브, 사랑이오\"라고 말할 때 가만히 흔들리던 목소리가 잊히지 않는다.",
  },
];

export const novels: ArchiveItem[] = [
  {
    title: "노르웨이의 숲",
    original: "Norwegian Wood",
    year: "Haruki Murakami",
    note: "60년대 도쿄, 청춘의 상실과 사랑을 그린 무라카미의 대표작.",
    record: "\"죽음은 삶의 반대편이 아니라, 그 일부로 존재한다\"는 문장에서 책을 덮었다.",
  },
  {
    title: "1984",
    original: "1984",
    year: "George Orwell",
    note: "전체주의 사회를 그려낸 오웰의 디스토피아 소설.",
    record: "마지막 페이지에서 그가 \"빅 브라더를 사랑했다\"고 적은 줄에 한참 멈춰 있었다.",
  },
  {
    title: "위대한 개츠비",
    original: "The Great Gatsby",
    year: "F. Scott Fitzgerald",
    note: "1920년대 미국, 한 남자의 환상과 환멸에 관한 소설.",
    record: "강 건너 초록 불빛을 바라보던 뒷모습이, 모든 그리움의 모양 같았다.",
  },
  {
    title: "어린 왕자",
    original: "The Little Prince",
    year: "Antoine de Saint-Exupéry",
    note: "별에서 온 작은 왕자가 사막에서 들려주는 우화.",
    record: "\"네가 길들인 것에 대해 영원히 책임이 있다\"는 한 줄을 오래 눌러두었다.",
  },
  {
    title: "데미안",
    original: "Demian",
    year: "Hermann Hesse",
    note: "한 소년이 자기 자신을 찾아가는 헤세의 성장 소설.",
    record: "\"새는 알을 깨고 나온다\"는 문장 위에, 손가락이 한참 머물렀다.",
  },
  {
    title: "참을 수 없는 존재의 가벼움",
    original: "The Unbearable Lightness of Being",
    year: "Milan Kundera",
    note: "프라하의 봄을 배경으로 한 사랑과 존재에 관한 철학 소설.",
    record: "한 번뿐인 삶은 살아본 적 없는 것과 같다는 말이, 어딘가에 깊게 가라앉았다.",
  },
  {
    title: "자기 앞의 생",
    original: "The Life Before Us",
    year: "Romain Gary",
    note: "파리 변두리, 늙은 여자와 아랍 소년의 따뜻한 동거 이야기.",
    record: "\"사랑해야 한다\"는 마지막 문장이, 어떤 큰 결말보다 묵직했다.",
  },
  {
    title: "해리 포터와 마법사의 돌",
    original: "Harry Potter and the Sorcerer's Stone",
    year: "J.K. Rowling",
    note: "마법학교에 입학한 한 소년의 첫 번째 모험.",
    record: "처음 호그와트 편지가 폭우처럼 쏟아지던 장면에, 어린 마음이 같이 두근거렸다.",
  },
];

export const folders: {
  id: Category;
  label: string;
  korean: string;
  english: string;
  items: ArchiveItem[];
  hue: string;
}[] = [
  { id: "movie", label: "Movies", korean: "영화", english: "the silver screen", items: movies, hue: "amber" },
  { id: "drama", label: "Dramas", korean: "드라마", english: "long evenings", items: dramas, hue: "sepia" },
  { id: "novel", label: "Novels", korean: "소설", english: "underlined pages", items: novels, hue: "wood" },
];

export const collections = [
  {
    title: "비 오는 날의 영화들",
    count: 7,
    excerpt: "창밖의 빗소리와 함께 다시 보고 싶었던 장면들. 우산 없이 걷는 인물, 젖은 거리, 흐려진 네온…",
    tag: "Movies",
  },
  {
    title: "겨울 밤에 읽은 문장",
    count: 12,
    excerpt: "이불 속에서 밑줄 그었던 문장들. 노르웨이의 숲, 데미안, 그리고 어린 왕자의 한 페이지.",
    tag: "Novels",
  },
  {
    title: "오래 남은 인물들",
    count: 9,
    excerpt: "이름은 잊었지만 표정은 남아 있는 사람들. 동훈 아저씨, 캐롤, 그리고 그 모든 조용한 얼굴들.",
    tag: "Dramas",
  },
  {
    title: "엔딩 크레딧이 길었던 작품",
    count: 5,
    excerpt: "끝나도 자리에서 일어날 수 없었던 영화들. 음악이 멎을 때까지 앉아 있던 시간들.",
    tag: "Movies",
  },
];
