import { motion } from "framer-motion";
import heroImage from "@/assets/library-hero.jpg";
import SearchOracle from "./SearchOracle";
import PageTurnArrow from "./PageTurnArrow";
import type { WorkResult } from "@/types/work";

interface Props {
  onStartRecord?: (work: WorkResult) => void;
}

const Hero = ({ onStartRecord }: Props) => {
  return (
    <section id="hero" className="relative min-h-screen w-full overflow-hidden">
      {/* Background photo, very faded, behind content */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="따뜻한 빛이 스며드는 오래된 서재"
          width={1536}
          height={1024}
          className="h-full w-full object-cover photo-vintage opacity-[0.32]"
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse at center, hsl(60 14% 97% / 0.55) 0%, hsl(60 14% 97% / 0.92) 70%)",
          }}
        />
      </div>

      {/* Soft candle glow */}
      <div className="absolute left-1/2 top-1/3 h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 candle-glow rounded-full" />

      <div className="relative z-10 mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center px-6 py-24 text-center">
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 2, delay: 0.3 }}
          className="mb-6 font-serif-soft text-sm tracking-[0.4em] text-ink-soft uppercase"
        >
          a quiet archive of memory
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 2.2, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="relative w-full"
        >
          <h1 className="font-display whitespace-nowrap text-[2rem] leading-[1.1] tracking-tight text-ink sm:text-5xl md:text-6xl lg:text-7xl">
            <span aria-hidden className="font-display text-wood/40">“</span>
            <span className="font-light text-wood">기억을 모아두는 곳</span>
            <span aria-hidden className="font-display text-wood/40">”</span>
          </h1>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 2, delay: 1.0 }}
          className="mt-12 max-w-xl font-body text-base leading-relaxed text-ink-soft text-balance md:text-lg"
        >
          영화의 한 장면, 드라마의 한 마디, 책의 한 줄.
          <br />
          잊고 싶지 않은 순간들을 천천히 기록하는 공간입니다.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.8, delay: 1.3 }}
          className="mt-14 w-full"
        >
          <SearchOracle onStartRecord={onStartRecord} />
        </motion.div>

        <PageTurnArrow targetId="folders" label="서재 안으로 들어가다" />
      </div>
    </section>
  );
};

export default Hero;
