import { ReactNode } from "react";

/**
 * Decorative serif quotation marks — old print / book mood.
 * Acts as a soft frame around quoted text.
 */
interface QuoteProps {
  children: ReactNode;
  align?: "center" | "left";
  size?: "sm" | "md" | "lg";
  faded?: boolean;
}

const sizeMap = {
  sm: { mark: "text-[5rem] md:text-[6rem]", offset: "-mt-6" },
  md: { mark: "text-[7rem] md:text-[9rem]", offset: "-mt-10" },
  lg: { mark: "text-[10rem] md:text-[14rem]", offset: "-mt-16" },
};

const Quote = ({ children, align = "center", size = "md", faded = false }: QuoteProps) => {
  const s = sizeMap[size];
  const opacity = faded ? "opacity-[0.08]" : "opacity-25";
  return (
    <div className={`relative ${align === "center" ? "text-center" : "text-left"}`}>
      <span
        aria-hidden
        className={`pointer-events-none select-none font-display italic leading-none text-wood ${s.mark} ${opacity}`}
        style={{ display: "block" }}
      >
        “
      </span>
      <div className={`relative ${s.offset}`}>{children}</div>
      <span
        aria-hidden
        className={`pointer-events-none mt-2 block select-none text-right font-display italic leading-none text-wood ${s.mark} ${opacity}`}
      >
        ”
      </span>
    </div>
  );
};

export default Quote;
