import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { addMemory, enrichMemoriesByTitle, memoriesForTitle } from "@/lib/memoryStore";
import { supabase } from "@/integrations/supabase/client";
import type { WorkResult } from "@/types/work";

interface Props {
  prefilledWork?: WorkResult;
}

type Cat = "movie" | "drama" | "novel";

const categoryLabel: Record<Cat, string> = {
  movie: "영화",
  drama: "드라마",
  novel: "소설",
};

const RecordEntry = ({ prefilledWork }: Props) => {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [category, setCategory] = useState<Cat>("movie");
  // 이 페이지 안에서 자동 정리된 작품 메타 (AI 보강 결과 또는 검색에서 넘어온 결과)
  const [enriched, setEnriched] = useState<WorkResult | null>(null);
  const [enriching, setEnriching] = useState(false);

  useEffect(() => {
    if (prefilledWork) {
      setTitle(prefilledWork.title);
      setCategory(prefilledWork.category);
      setEnriched(prefilledWork);
    }
  }, [prefilledWork]);

  // 제목이 비거나 enriched 작품과 달라지면 enriched 해제
  useEffect(() => {
    if (enriched && title.trim().toLowerCase() !== enriched.title.trim().toLowerCase()) {
      setEnriched(null);
    }
  }, [title, enriched]);

  const fetchEnrichment = async (q: string): Promise<WorkResult | null> => {
    const { data, error } = await supabase.functions.invoke("analyze-work", {
      body: { query: q },
    });
    if (error) {
      console.error(error);
      return null;
    }
    if ((data as { error?: string })?.error) {
      toast((data as { error: string }).error);
      return null;
    }
    return data as WorkResult;
  };

  const handleEnrich = async () => {
    const q = title.trim();
    if (!q) {
      toast("작품 제목을 먼저 적어주세요.");
      return;
    }
    setEnriching(true);
    try {
      const result = await fetchEnrichment(q);
      if (result) {
        setEnriched(result);
        setCategory(result.category);
        // 제목을 표준 표기로 살며시 정리
        if (result.title && result.title !== title) setTitle(result.title);
        toast("작품 정보를 책장에 정리해 두었어요.");
      } else {
        toast("이 작품을 찾지 못했어요.");
      }
    } catch (e) {
      console.error(e);
      toast("작품을 불러오지 못했어요. 잠시 후 다시 시도해 주세요.");
    } finally {
      setEnriching(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const t = title.trim();
    if (!t && !body.trim()) {
      toast("빈 페이지는 잠시 두어요.");
      return;
    }

    // 제목은 있는데 메타가 비어있다면, 저장 직전에 한 번 자동 보강 시도
    let meta = enriched;
    if (t && !meta) {
      try {
        setEnriching(true);
        meta = await fetchEnrichment(t);
        if (meta) {
          setEnriched(meta);
          setCategory(meta.category);
        }
      } catch {
        // 보강 실패해도 저장은 진행 — 조용한 실패
      } finally {
        setEnriching(false);
      }
    }

    const finalCategory = meta?.category ?? category;
    const finalTitle = meta?.title || t || "이름 없는 기억";

    // 폴더 카드에는 짧은 한 줄(shortDescription)을, 검색 결과의 긴 설명은 저장하지 않음
    const folderNote = meta?.shortDescription || meta?.description;

    addMemory({
      title: finalTitle,
      body: body.trim(),
      category: finalCategory,
      originalTitle: meta?.originalTitle,
      year: meta?.year,
      description: folderNote,
      emotionTags: meta?.emotionTags,
    });

    // 같은 작품의 다른 기록들에도 메타를 보강해, 카드가 항상 풍성하게 보이도록
    if (meta) {
      enrichMemoriesByTitle(finalTitle, {
        originalTitle: meta.originalTitle,
        year: meta.year,
        description: folderNote,
        emotionTags: meta.emotionTags,
        category: meta.category,
      });
    }

    toast("기억을 책장에 꽂아두었어요.", {
      description: `${categoryLabel[finalCategory]} 폴더로 옮겨갈게요.`,
    });

    setTitle("");
    setBody("");
    setEnriched(null);

    setTimeout(() => {
      window.dispatchEvent(
        new CustomEvent("ql:open-folder", { detail: { category: finalCategory } })
      );
      const el = document.getElementById("folders");
      el?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 400);
  };

  const previousMemories = title.trim() ? memoriesForTitle(title) : [];

  return (
    <section id="record" className="relative px-6 py-32 md:py-40">
      <div className="mx-auto max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
          className="mb-14 text-center"
        >
          <p className="mb-4 font-serif-soft text-xs tracking-[0.4em] text-ink-soft uppercase">
            — write a memory —
          </p>
          <h2 className="font-display text-4xl text-ink md:text-5xl">
            <span aria-hidden className="font-display text-wood/40">"</span>
            오늘의 <span className="font-light text-wood">한 페이지</span>
            <span aria-hidden className="font-display text-wood/40">"</span>
          </h2>
          <p className="mx-auto mt-5 max-w-md font-body text-base leading-relaxed text-ink-soft">
            마음에 남은 작품을 골라, 천천히 옮겨 적어보세요.
          </p>
          <div className="ink-divider mt-8" />
        </motion.div>

        {/* Soft "afterglow" of the searched (or AI-enriched) work */}
        {enriched && (
          <motion.aside
            key={enriched.title}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
            className="paper-card relative mb-10 p-7 md:p-8"
          >
            <div className="flex items-baseline justify-between border-b border-ink/10 pb-3">
              <span className="font-serif-soft text-[11px] tracking-[0.4em] text-wood uppercase">
                {categoryLabel[enriched.category]}
                {enriched.year && (
                  <span className="ml-2 text-ink-soft/70">· {enriched.year}</span>
                )}
              </span>
              <span className="font-serif-soft text-[10px] italic text-ink-soft/60">
                — 기록하기 전, 한 번 더 —
              </span>
            </div>

            <h3 className="mt-4 font-display text-2xl text-ink md:text-3xl">
              {enriched.title}
            </h3>
            {enriched.originalTitle &&
              enriched.originalTitle !== enriched.title && (
                <p className="mt-1 font-serif-soft text-sm italic text-ink-soft">
                  {enriched.originalTitle}
                </p>
              )}

            <p className="mt-4 font-body text-base leading-relaxed text-ink-soft text-balance">
              {enriched.description}
            </p>

            {enriched.emotionTags?.length > 0 && (
              <div className="mt-5 flex flex-wrap gap-2">
                {enriched.emotionTags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-wood/30 bg-paper-warm/60 px-3 py-1 font-serif-soft text-xs italic text-wood-deep"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}

            {enriched.gentleLine && (
              <p className="mt-5 font-serif-soft text-sm italic text-ink-soft/80">
                "{enriched.gentleLine}"
              </p>
            )}
          </motion.aside>
        )}

        <motion.form
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 1.8, ease: [0.22, 1, 0.36, 1] }}
          onSubmit={handleSave}
          className="paper-card relative p-10 md:p-14"
        >
          {/* Margin line, like notebook */}
          <div className="pointer-events-none absolute left-12 top-0 h-full w-px bg-destructive/20" />

          {/* Category — paper label tabs */}
          <div className="mb-8">
            <label className="mb-3 block font-serif-soft text-[11px] tracking-[0.3em] text-ink-soft uppercase">
              어디에 꽂아둘까요
            </label>
            <div className="flex flex-wrap gap-2">
              {(Object.keys(categoryLabel) as Cat[]).map((c) => {
                const active = category === c;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCategory(c)}
                    data-cursor="hover"
                    className={`relative border px-5 py-2 font-serif-soft text-xs italic tracking-[0.25em] uppercase transition-all duration-500 ${
                      active
                        ? "border-wood bg-wood text-paper shadow-paper"
                        : "border-wood/30 bg-paper-warm/40 text-wood hover:bg-paper-warm/70"
                    }`}
                    style={{
                      transform: active ? "rotate(-0.6deg)" : "rotate(0.4deg)",
                    }}
                  >
                    {categoryLabel[c]}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mb-8">
            <label className="mb-2 block font-serif-soft text-[11px] tracking-[0.3em] text-ink-soft uppercase">
              제목
            </label>
            <div className="flex items-end gap-3">
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    if (!enriching && title.trim()) handleEnrich();
                  }
                }}
                placeholder="어떤 작품이었나요?"
                className="min-w-0 flex-1 border-b border-ink/20 bg-transparent pb-3 font-display text-2xl text-ink placeholder:font-serif-soft placeholder:text-base placeholder:italic placeholder:text-ink-soft/50 focus:border-wood focus:outline-none transition-colors duration-700"
              />
              <button
                type="button"
                onClick={handleEnrich}
                disabled={enriching || !title.trim()}
                data-cursor="hover"
                title="작품 정보를 자동으로 정리해 드려요"
                className="mb-1 inline-flex shrink-0 items-center gap-2 whitespace-nowrap border border-wood/40 bg-paper-warm/40 px-4 py-1.5 font-serif-soft text-[11px] italic tracking-[0.2em] text-wood uppercase transition-all duration-500 hover:bg-wood hover:text-paper disabled:opacity-40"
              >
                {enriching ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <>
                    <Sparkles className="h-3 w-3" strokeWidth={1.4} />
                    정리하기
                  </>
                )}
              </button>
            </div>
            <p className="mt-2 font-serif-soft text-[11px] italic text-ink-soft/60">
              제목만 적고 정리하기를 누르면 작품 정보를 책장처럼 정리해 드려요.
            </p>
          </div>

          <div className="mb-10">
            <label className="mb-2 block font-serif-soft text-[11px] tracking-[0.3em] text-ink-soft uppercase">
              그날의 마음
            </label>
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="마음에 오래 남은 장면이 있다면 남겨주세요"
              rows={6}
              className="w-full resize-none border-b border-ink/20 bg-transparent pb-3 font-display text-2xl leading-snug text-ink placeholder:font-serif-soft placeholder:text-base placeholder:italic placeholder:text-ink-soft/50 focus:border-wood focus:outline-none transition-colors duration-700"
            />
          </div>

          <div className="flex items-center justify-between border-t border-ink/10 pt-6">
            <span className="font-serif-soft text-xs italic text-ink-soft">
              {new Date().toLocaleDateString("ko-KR", {
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </span>

            <button
              type="submit"
              disabled={enriching}
              className="group relative overflow-hidden border border-wood/40 bg-transparent px-8 py-3 font-serif-soft text-sm tracking-[0.2em] text-wood uppercase transition-all duration-700 hover:bg-wood hover:text-paper disabled:opacity-50"
            >
              {enriching ? "정리하는 중…" : "조용히 보관하기"}
            </button>
          </div>
        </motion.form>

        {previousMemories.length > 0 && (
          <div className="mt-10 paper-card p-7 md:p-8">
            <p className="mb-4 font-serif-soft text-[11px] tracking-[0.3em] text-ink-soft uppercase">
              — 이전에 적어둔 기록 ({previousMemories.length}) —
            </p>
            <ul className="space-y-4">
              {previousMemories.map((m) => (
                <li key={m.id} className="border-b border-dashed border-ink/15 pb-3 last:border-0">
                  <p className="font-serif-soft text-xs italic text-ink-soft/70">
                    {new Date(m.date).toLocaleDateString("ko-KR")}
                  </p>
                  <p className="mt-1 font-body text-base leading-relaxed text-ink">
                    {m.body || "조용히 비워둔 페이지."}
                  </p>
                </li>
              ))}
            </ul>
          </div>
        )}

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 2, delay: 0.4 }}
          className="mt-20 text-center font-serif-soft text-sm italic text-ink-soft/70"
        >
          — 어떤 기억은 오래 남기 위해 적어둘 필요가 있다 —
        </motion.p>
      </div>
    </section>
  );
};

export default RecordEntry;
