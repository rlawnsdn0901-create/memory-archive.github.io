import { motion } from "framer-motion";

interface Props {
  targetId?: string;
  label?: string;
}

/**
 * Subtle "turn the page / descend a floor" arrow.
 * Slow, breath-like animation. Click scrolls to the next section.
 */
const PageTurnArrow = ({ targetId, label = "다음 장을 펼치다" }: Props) => {
  const handleClick = () => {
    if (targetId) {
      const el = document.getElementById(targetId);
      el?.scrollIntoView({ behavior: "smooth", block: "start" });
    } else {
      window.scrollBy({ top: window.innerHeight * 0.9, behavior: "smooth" });
    }
  };

  return (
    <motion.button
      onClick={handleClick}
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 2, delay: 0.3 }}
      className="group mx-auto mt-16 flex flex-col items-center gap-3 text-ink-soft/70 transition-colors duration-700 hover:text-wood"
      aria-label={label}
    >
      <span className="font-serif-soft text-[10px] italic tracking-[0.4em] uppercase">
        {label}
      </span>
      <motion.div
        animate={{ y: [0, 6, 0] }}
        transition={{ duration: 3.6, repeat: Infinity, ease: "easeInOut" }}
        className="flex flex-col items-center"
      >
        {/* Hand-drawn style arrow: a thin downward stroke + open chevron */}
        <svg width="22" height="36" viewBox="0 0 22 36" fill="none" aria-hidden>
          <path
            d="M11 1 C 11 12, 11 22, 11 30"
            stroke="currentColor"
            strokeWidth="1"
            strokeLinecap="round"
            opacity="0.65"
          />
          <path
            d="M3 24 C 6 28, 9 31, 11 33 C 13 31, 16 28, 19 24"
            stroke="currentColor"
            strokeWidth="1"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
          />
        </svg>
      </motion.div>
    </motion.button>
  );
};

export default PageTurnArrow;
