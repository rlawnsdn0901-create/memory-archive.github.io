import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { type ArchiveItem, type Category } from "@/data/archive";
import {
  memoriesForTitle,
  updateMemory,
  deleteMemory,
  addMemory,
  imagesForTitle,
  addImageForTitle,
  removeImageForTitle,
  type Memory,
} from "@/lib/memoryStore";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onClose: () => void;
  item: ArchiveItem | null;
  category: Category | null;
}

const categoryLabel: Record<Category, string> = {
  movie: "영화",
  drama: "드라마",
  novel: "소설",
};

const moodTags = (note?: string) => {
  if (!note) return [];
  return ["여운", "잔잔함", "기억"];
};

// 이미지 한 변의 최대 크기 (저장 용량 절약)
const MAX_DIM = 1200;

const fileToCompressedDataUrl = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("read failed"));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("decode failed"));
      img.onload = () => {
        const ratio = Math.min(1, MAX_DIM / Math.max(img.width, img.height));
        const w = Math.round(img.width * ratio);
        const h = Math.round(img.height * ratio);
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("no canvas ctx"));
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", 0.82));
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  });

const WorkDetailModal = ({ open, onClose, item, category }: Props) => {
  const [memories, setMemories] = useState<Memory[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [adding, setAdding] = useState(false);
  const [newBody, setNewBody] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const refresh = () => {
    if (item) {
      setMemories(memoriesForTitle(item.title));
      setImages(imagesForTitle(item.title));
    }
  };

  useEffect(() => {
    if (open && item) {
      setMemories(memoriesForTitle(item.title));
      setImages(imagesForTitle(item.title));
      setEditingId(null);
      setAdding(false);
      setNewBody("");
      setLightbox(null);
    }
  }, [open, item]);

  useEffect(() => {
    const onChange = () => refresh();
    window.addEventListener("ql:memories-changed", onChange);
    window.addEventListener("ql:work-images-changed", onChange);
    return () => {
      window.removeEventListener("ql:memories-changed", onChange);
      window.removeEventListener("ql:work-images-changed", onChange);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [item]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (lightbox) setLightbox(null);
        else onClose();
      }
    };
    if (open) window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose, lightbox]);

  const startEdit = (m: Memory) => {
    setEditingId(m.id);
    setDraft(m.body);
  };

  const saveEdit = (id: string) => {
    updateMemory(id, { body: draft.trim() });
    setEditingId(null);
    toast("기록을 다시 정리해두었어요.");
  };

  const handleDelete = (id: string) => {
    deleteMemory(id);
    toast("이 기록은 조용히 덮어두었어요.");
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!item || !category) return;
    if (!newBody.trim()) {
      toast("빈 페이지는 잠시 두어요.");
      return;
    }
    // 작품 메타(영문 제목/년도/설명)도 함께 보존 — 같은 작품이 카드로 중복 생성되지 않도록
    addMemory({
      title: item.title,
      body: newBody.trim(),
      category,
      originalTitle: item.original,
      year: item.year,
      description: item.note,
    });
    setNewBody("");
    setAdding(false);
    toast("이 작품 옆에 한 줄 더 적어두었어요.");
  };

  const handleFiles = async (files: FileList | null) => {
    if (!files || !item) return;
    const list = Array.from(files).filter((f) => f.type.startsWith("image/"));
    if (list.length === 0) return;
    try {
      for (const f of list) {
        const dataUrl = await fileToCompressedDataUrl(f);
        addImageForTitle(item.title, dataUrl);
      }
      toast(list.length === 1 ? "사진 한 장을 끼워두었어요." : `사진 ${list.length}장을 끼워두었어요.`);
    } catch {
      toast("사진을 끼워두지 못했어요. 다시 시도해 주세요.");
    }
  };

  const handleRemoveImage = (idx: number) => {
    if (!item) return;
    removeImageForTitle(item.title, idx);
    toast("사진 한 장을 빼두었어요.");
  };

  return (
    <AnimatePresence>
      {open && item && category && (
        <motion.div
          key="overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6 }}
          className="fixed inset-0 z-[90] flex items-center justify-center bg-ink/40 px-4 py-10 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="paper-card relative max-h-[85vh] w-full max-w-xl overflow-y-auto p-8 md:p-10"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={onClose}
              data-cursor="hover"
              aria-label="닫기"
              className="absolute right-5 top-4 font-serif-soft text-xs italic tracking-widest text-ink-soft hover:text-wood transition-colors"
            >
              닫기 ✕
            </button>

            <div className="flex items-baseline justify-between border-b border-ink/10 pb-3 pr-12">
              <span className="font-serif-soft text-[11px] tracking-[0.4em] text-wood uppercase">
                {categoryLabel[category]}
                {item.year && <span className="ml-2 text-ink-soft/70">· {item.year}</span>}
              </span>
              <span className="font-serif-soft text-[10px] italic text-ink-soft/60">
                from the folder
              </span>
            </div>

            <h3 className="mt-5 font-display text-3xl text-ink md:text-4xl">
              {item.title}
            </h3>
            {item.original && (
              <p className="mt-1 font-serif-soft text-sm italic text-ink-soft">
                {item.original}
              </p>
            )}

            <p className="mt-5 font-body text-base leading-relaxed text-ink-soft text-balance">
              {item.note}
            </p>

            <div className="mt-6">
              <p className="mb-3 font-serif-soft text-[10px] tracking-[0.3em] text-ink-soft uppercase">
                — 감정 태그 —
              </p>
              <div className="flex flex-wrap gap-2">
                {moodTags(item.note).map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-wood/30 bg-paper-warm/60 px-3 py-1 font-serif-soft text-xs italic text-wood-deep"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* ===== 내가 남긴 기록 ===== */}
            <div className="mt-8 border-t border-ink/10 pt-5">
              <div className="mb-3 flex items-center justify-between">
                <p className="font-serif-soft text-[11px] tracking-[0.3em] text-ink-soft uppercase">
                  — 내가 남긴 기록 —
                </p>
                {!adding && (
                  <button
                    type="button"
                    onClick={() => setAdding(true)}
                    data-cursor="hover"
                    className="font-serif-soft text-[11px] italic tracking-[0.2em] text-wood uppercase hover:text-wood-deep"
                  >
                    + 한 줄 더
                  </button>
                )}
              </div>

              {adding && (
                <form
                  onSubmit={handleAdd}
                  className="mb-5 space-y-3 border-l-2 border-wood/40 bg-paper-warm/40 px-5 py-4"
                >
                  <textarea
                    autoFocus
                    value={newBody}
                    onChange={(e) => setNewBody(e.target.value)}
                    placeholder="기억에 남는 장면이나 대사를 적어보세요"
                    rows={3}
                    className="w-full resize-none bg-transparent font-serif-soft text-base italic leading-relaxed text-ink placeholder:text-ink-soft/50 focus:outline-none"
                  />
                  <div className="flex items-center gap-3">
                    <button
                      type="submit"
                      className="border border-wood/40 px-4 py-1.5 font-serif-soft text-xs italic tracking-[0.2em] text-wood uppercase hover:bg-wood hover:text-paper transition-all duration-500"
                    >
                      적어두기
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setAdding(false);
                        setNewBody("");
                      }}
                      className="font-serif-soft text-xs italic text-ink-soft hover:text-wood"
                    >
                      취소
                    </button>
                  </div>
                </form>
              )}

              <ul className="space-y-4">
                {/* 작품에 새겨진 기본 한 줄 — 항상 첫 줄로 보존 */}
                {item.record && (
                  <li className="border-b border-dashed border-ink/15 pb-3 last:border-0">
                    <div className="flex items-baseline justify-between gap-3">
                      <p className="font-serif-soft text-xs italic text-ink-soft/60">
                        — 처음 새겨둔 한 줄 —
                      </p>
                    </div>
                    <p className="mt-1 font-body text-base leading-relaxed text-ink">
                      {item.record}
                    </p>
                  </li>
                )}

                {memories.map((m) => (
                  <li
                    key={m.id}
                    className="border-b border-dashed border-ink/15 pb-3 last:border-0"
                  >
                    <div className="flex items-baseline justify-between gap-3">
                      <p className="font-serif-soft text-xs italic text-ink-soft/70">
                        {new Date(m.date).toLocaleDateString("ko-KR")}
                      </p>
                      {editingId !== m.id && (
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => startEdit(m)}
                            data-cursor="hover"
                            className="font-serif-soft text-[11px] italic tracking-[0.15em] text-wood hover:text-wood-deep"
                          >
                            고치기
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(m.id)}
                            data-cursor="hover"
                            className="font-serif-soft text-[11px] italic tracking-[0.15em] text-ink-soft/70 hover:text-destructive"
                          >
                            지우기
                          </button>
                        </div>
                      )}
                    </div>

                    {editingId === m.id ? (
                      <div className="mt-2 space-y-2">
                        <textarea
                          autoFocus
                          value={draft}
                          onChange={(e) => setDraft(e.target.value)}
                          rows={3}
                          className="w-full resize-none border-b border-ink/20 bg-transparent pb-2 font-body text-base leading-relaxed text-ink focus:border-wood focus:outline-none"
                        />
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => saveEdit(m.id)}
                            className="border border-wood/40 px-3 py-1 font-serif-soft text-xs italic tracking-[0.2em] text-wood uppercase hover:bg-wood hover:text-paper transition-all duration-500"
                          >
                            저장
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingId(null)}
                            className="font-serif-soft text-xs italic text-ink-soft hover:text-wood"
                          >
                            취소
                          </button>
                        </div>
                      </div>
                    ) : (
                      <p className="mt-1 font-body text-base leading-relaxed text-ink">
                        {m.body || "조용히 비워둔 페이지."}
                      </p>
                    )}
                  </li>
                ))}
              </ul>
            </div>

            {/* ===== 끼워둔 사진 ===== */}
            <div className="mt-8 border-t border-ink/10 pt-5">
              <div className="mb-4 flex items-center justify-between">
                <p className="font-serif-soft text-[11px] tracking-[0.3em] text-ink-soft uppercase">
                  — 끼워둔 사진 —
                </p>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  data-cursor="hover"
                  className="font-serif-soft text-[11px] italic tracking-[0.2em] text-wood uppercase hover:text-wood-deep"
                >
                  + 사진 끼우기
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    handleFiles(e.target.files);
                    e.currentTarget.value = "";
                  }}
                />
              </div>

              {images.length === 0 ? (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  data-cursor="hover"
                  className="block w-full border border-dashed border-wood/35 bg-paper-warm/25 px-6 py-7 text-center font-serif-soft text-xs italic text-ink-soft/80 hover:bg-paper-warm/45 transition-colors"
                >
                  이 작품과 함께 보관하고 싶은 사진을 끼워두세요.
                </button>
              ) : (
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                  {images.map((src, idx) => (
                    <div
                      key={idx}
                      className={`group relative photo-frame bg-paper-warm p-2 ${
                        idx % 3 === 0 ? "tilt-tiny-1" : idx % 3 === 1 ? "tilt-tiny-2" : "tilt-tiny-3"
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => setLightbox(src)}
                        data-cursor="hover"
                        className="block w-full overflow-hidden"
                        aria-label="사진 크게 보기"
                      >
                        <img
                          src={src}
                          alt={`${item.title} 관련 사진 ${idx + 1}`}
                          loading="lazy"
                          className="h-32 w-full object-cover photo-vintage transition-transform duration-700 group-hover:scale-[1.02]"
                        />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(idx)}
                        data-cursor="hover"
                        aria-label="사진 빼기"
                        className="absolute right-1 top-1 rounded-full bg-paper/85 px-2 py-0.5 font-serif-soft text-[10px] italic text-ink-soft opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                      >
                        빼기 ✕
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>

          {/* Lightbox */}
          {lightbox && (
            <div
              className="absolute inset-0 z-[110] flex items-center justify-center bg-ink/80 p-6"
              onClick={(e) => {
                e.stopPropagation();
                setLightbox(null);
              }}
            >
              <img
                src={lightbox}
                alt="크게 본 사진"
                className="max-h-full max-w-full object-contain photo-vintage shadow-paper"
              />
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default WorkDetailModal;
