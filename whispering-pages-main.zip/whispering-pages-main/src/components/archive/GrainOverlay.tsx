/**
 * Fixed full-screen film grain + dust + vignette overlay.
 * Sits above content but below pointer events.
 */
const GrainOverlay = () => {
  return (
    <div className="pointer-events-none fixed inset-0 z-[60]">
      {/* Film grain */}
      <div
        className="absolute inset-0 opacity-[0.16] mix-blend-multiply"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0.22  0 0 0 0 0.17  0 0 0 0 0.13  0 0 0 0.55 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>\")",
        }}
      />
      {/* Dust specks — slow drift */}
      <div
        className="dust-layer-a absolute -inset-6 opacity-[0.12] mix-blend-multiply"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='600'><filter id='d'><feTurbulence type='fractalNoise' baseFrequency='0.012' numOctaves='1'/><feColorMatrix values='0 0 0 0 0.3  0 0 0 0 0.2  0 0 0 0 0.15  0 0 0 1 0'/><feComponentTransfer><feFuncA type='discrete' tableValues='0 0 0 0 0 0 0 0 0 1'/></feComponentTransfer></filter><rect width='100%' height='100%' filter='url(%23d)'/></svg>\")",
        }}
      />
      <div
        className="dust-layer-b absolute -inset-6 opacity-[0.08] mix-blend-multiply"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='800'><filter id='d2'><feTurbulence type='fractalNoise' baseFrequency='0.008' numOctaves='1' seed='5'/><feColorMatrix values='0 0 0 0 0.32  0 0 0 0 0.22  0 0 0 0 0.16  0 0 0 1 0'/><feComponentTransfer><feFuncA type='discrete' tableValues='0 0 0 0 0 0 0 0 0 0 0 1'/></feComponentTransfer></filter><rect width='100%' height='100%' filter='url(%23d2)'/></svg>\")",
        }}
      />
      {/* Vignette */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 50%, hsl(24 35% 18% / 0.22) 100%)",
        }}
      />
    </div>
  );
};

export default GrainOverlay;
