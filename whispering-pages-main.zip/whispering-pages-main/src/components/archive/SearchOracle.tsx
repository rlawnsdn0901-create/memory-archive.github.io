import { motion, AnimatePresence } from "framer-motion";
import { Search, Loader2 } from "lucide-react";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import Quote from "./Quote";
import type { WorkResult } from "@/types/work";

const categoryLabel: Record<WorkResult["category"], string> = {
  movie: "영화",
  drama: "드라마",
  novel: "소설",
};

interface Props {
  onStartRecord?: (work: WorkResult) => void;
}

const SearchOracle = ({ onStartRecord }: Props) => {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<WorkResult | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (!q) return;
    setLoading(true);
    setResult(null);
    try {
      const { data, error } = await supabase.functions.invoke("analyze-work", {
        body: { query: q },
      });
      if (error) throw error;
      if ((data as { error?: string })?.error) {
        toast(data.error);
        return;
      }
      setResult(data as WorkResult);
    } catch (err) {
      console.error(err);
      toast("작품을 불러오지 못했어요. 잠시 후 다시 시도해 주세요.");
    } finally {
      setLoading(false);
    }
  };

  const startRecord = () => {
    if (!result) return;
    onStartRecord?.(result);
    const el = document.getElementById("record");
    el?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="w-full">
      <form
        onSubmit={handleSearch}
        className="group relative mx-auto flex max-w-xl items-center gap-3 border-b border-ink/30 pb-3 transition-colors duration-700 focus-within:border-wood"
      >
        <Search className="h-4 w-4 shrink-0 text-ink-soft" strokeWidth={1.2} />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="기억에 남은 작품을 찾아보세요"
          className="min-w-0 flex-1 bg-transparent font-serif-soft text-base text-ink placeholder:text-ink-soft/60 focus:outline-none md:text-lg"
          disabled={loading}
        />
        <button
          type="submit"
          disabled={loading || !query.trim()}
          data-cursor="hover"
          className="inline-flex shrink-0 items-center gap-2 whitespace-nowrap border border-wood/40 bg-paper-warm/40 px-4 py-1.5 font-serif-soft text-xs italic tracking-[0.2em] text-wood uppercase transition-all duration-500 hover:bg-wood hover:text-paper disabled:opacity-40"
        >
          {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <>찾기</>}
        </button>
      </form>

      <AnimatePresence mode="wait">
        {loading && !result && (
          <motion.p
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="mt-8 text-center font-serif-soft text-sm italic text-ink-soft/70"
          >
            기억의 책장을 천천히 넘기는 중…
          </motion.p>
        )}

        {result && (
          <motion.article
            key={result.title}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 16 }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
            className="paper-card mx-auto mt-10 max-w-xl p-8 md:p-10"
          >
            <div className="flex items-baseline justify-between border-b border-ink/10 pb-4">
              <span className="font-serif-soft text-[11px] tracking-[0.4em] text-wood uppercase">
                {categoryLabel[result.category]}
                {result.year && <span className="ml-2 text-ink-soft/70">· {result.year}</span>}
              </span>
              <span className="font-serif-soft text-[10px] italic text-ink-soft/60">
                from the archive
              </span>
            </div>

            <h3 className="mt-5 font-display text-3xl text-ink md:text-4xl">
              {result.title}
            </h3>
            {result.originalTitle && result.originalTitle !== result.title && (
              <p className="mt-1 font-serif-soft text-sm italic text-ink-soft">
                {result.originalTitle}
              </p>
            )}

            <div className="mt-6">
              <Quote size="sm" faded>
                <p className="font-body text-base leading-relaxed text-ink-soft text-balance">
                  {result.description}
                </p>
              </Quote>
            </div>

            <div className="mt-6">
              <p className="mb-3 font-serif-soft text-[10px] tracking-[0.3em] text-ink-soft uppercase">
                — 감정 태그 —
              </p>
              <div className="flex flex-wrap gap-2">
                {result.emotionTags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-wood/30 bg-paper-warm/60 px-3 py-1 font-serif-soft text-xs italic text-wood-deep"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <p className="mt-8 font-serif-soft text-sm italic text-ink-soft/80">
              "{result.gentleLine}"
            </p>

            <button
              type="button"
              onClick={startRecord}
              data-cursor="hover"
              className="mt-6 w-full border border-wood/40 bg-transparent px-8 py-3 font-serif-soft text-sm tracking-[0.2em] text-wood uppercase transition-all duration-700 hover:bg-wood hover:text-paper"
            >
              이 기억을 기록하기
            </button>
          </motion.article>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SearchOracle;
