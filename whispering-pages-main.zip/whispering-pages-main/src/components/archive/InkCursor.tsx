import { useEffect, useRef, useState } from "react";

/**
 * Vintage fountain pen cursor + soft, smoothly-curving ink trail.
 * - The pen nib follows the pointer with gentle easing (rAF lerp) for a hand-held feel.
 * - Movement leaves a faint, faded ink ribbon that fades out quickly.
 * - On hoverable elements, the nib subtly tilts and brightens.
 * - Hidden on touch devices.
 */
type InkPath = {
  id: number;
  d: string;
};

// Build a smooth quadratic Bézier path from an array of points.
const buildSmoothPath = (pts: { x: number; y: number }[]): string => {
  if (pts.length < 2) return "";
  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 1; i < pts.length - 1; i++) {
    const xc = (pts[i].x + pts[i + 1].x) / 2;
    const yc = (pts[i].y + pts[i + 1].y) / 2;
    d += ` Q ${pts[i].x} ${pts[i].y} ${xc} ${yc}`;
  }
  const last = pts[pts.length - 1];
  d += ` T ${last.x} ${last.y}`;
  return d;
};

const InkCursor = () => {
  const penRef = useRef<HTMLDivElement>(null);
  const [enabled, setEnabled] = useState(false);
  const [hovering, setHovering] = useState(false);
  const [paths, setPaths] = useState<InkPath[]>([]);
  const bufferRef = useRef<{ x: number; y: number; t: number }[]>([]);
  const flushTimerRef = useRef<number | null>(null);
  const idRef = useRef(0);

  // Smoothing state
  const targetRef = useRef({ x: -100, y: -100 });
  const currentRef = useRef({ x: -100, y: -100 });
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    const isTouch = window.matchMedia("(hover: none)").matches;
    if (isTouch) return;
    setEnabled(true);
    document.documentElement.classList.add("ink-cursor-active");

    const flushBuffer = () => {
      const pts = bufferRef.current;
      if (pts.length >= 3) {
        const d = buildSmoothPath(pts);
        const id = ++idRef.current;
        setPaths((prev) => {
          const next = [...prev, { id, d }];
          return next.length > 4 ? next.slice(next.length - 4) : next;
        });
        window.setTimeout(() => {
          setPaths((prev) => prev.filter((p) => p.id !== id));
        }, 280);
      }
      const tail = pts[pts.length - 1];
      bufferRef.current = tail ? [tail] : [];
    };

    // rAF loop — eases the pen toward the cursor target.
    // Lerp factor ~0.42 = quick, snappy follow with a subtle hand-held softness.
    const tick = () => {
      const t = targetRef.current;
      const c = currentRef.current;
      c.x += (t.x - c.x) * 0.42;
      c.y += (t.y - c.y) * 0.42;
      if (penRef.current) {
        penRef.current.style.transform = `translate3d(${c.x - 2}px, ${c.y - 26}px, 0)`;
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);

    const onMove = (e: MouseEvent) => {
      targetRef.current = { x: e.clientX, y: e.clientY };

      const target = e.target as HTMLElement | null;
      const isHover =
        !!target?.closest(
          "a, button, input, textarea, select, [role='button'], [data-cursor='hover']"
        );
      setHovering(isHover);

      const now = performance.now();
      const buf = bufferRef.current;
      const last = buf[buf.length - 1];
      if (!last || Math.hypot(e.clientX - last.x, e.clientY - last.y) > 4) {
        buf.push({ x: e.clientX, y: e.clientY, t: now });
        if (buf.length > 12) buf.shift();
      }

      if (flushTimerRef.current) window.clearTimeout(flushTimerRef.current);
      flushTimerRef.current = window.setTimeout(flushBuffer, 50);

      if (buf.length >= 10) flushBuffer();
    };

    window.addEventListener("mousemove", onMove);
    return () => {
      window.removeEventListener("mousemove", onMove);
      if (flushTimerRef.current) window.clearTimeout(flushTimerRef.current);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      document.documentElement.classList.remove("ink-cursor-active");
    };
  }, []);

  if (!enabled) return null;

  return (
    <>
      <svg
        aria-hidden
        className="pointer-events-none fixed inset-0 z-[100] h-full w-full"
        style={{ overflow: "visible" }}
      >
        {paths.map((p) => (
          <path
            key={p.id}
            d={p.d}
            className="ink-trail-line"
            stroke="hsl(24 35% 28% / 0.28)"
            strokeWidth={0.6}
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
          />
        ))}
      </svg>

      <div
        ref={penRef}
        aria-hidden
        className={`pointer-events-none fixed left-0 top-0 z-[101] transition-[filter] duration-500 ease-out ${
          hovering ? "scale-[1.06]" : "scale-100"
        }`}
        style={{
          willChange: "transform",
          // Faded, ink-stained look — slight sepia + low-contrast drop shadow
          filter: hovering
            ? "sepia(0.35) saturate(0.85) drop-shadow(0 1px 1.5px hsl(24 35% 25% / 0.35))"
            : "sepia(0.4) saturate(0.8) opacity(0.92) drop-shadow(0 1px 1.2px hsl(24 35% 25% / 0.28))",
          transformOrigin: "0% 100%",
          transition: "filter 500ms ease-out, transform 400ms cubic-bezier(0.22, 1, 0.36, 1)",
        }}
      >
        <svg
          width="30"
          height="34"
          viewBox="0 0 28 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          style={{
            transform: hovering ? "rotate(-5deg)" : "rotate(-1deg)",
            transition: "transform 450ms cubic-bezier(0.22, 1, 0.36, 1)",
          }}
        >
          {/* Wooden barrel — warm, slightly worn wood tone */}
          <path
            d="M19 2 L25 8 L13 22 L7 16 Z"
            fill="hsl(24 38% 32%)"
            stroke="hsl(24 40% 18% / 0.55)"
            strokeWidth="0.7"
          />
          {/* Brass collar highlight — faded gold */}
          <path
            d="M16.5 4.5 L22.5 10.5 L20 13 L14 7 Z"
            fill="hsl(38 55% 58%)"
            opacity="0.7"
          />
          {/* Subtle wood grain line */}
          <path
            d="M18 5 L11.5 14"
            stroke="hsl(24 40% 18% / 0.3)"
            strokeWidth="0.4"
          />
          {/* Ink-stained nib — espresso, not pure black */}
          <path
            d="M7 16 L13 22 L5 30 L3 28 Z"
            fill="hsl(0 15% 18%)"
            stroke="hsl(0 20% 12% / 0.55)"
            strokeWidth="0.5"
          />
          {/* Nib slit highlight */}
          <path
            d="M5.5 22 L4 28"
            stroke="hsl(35 25% 78% / 0.55)"
            strokeWidth="0.4"
          />
          {/* Ink drop at the very tip — slightly bleeding */}
          <circle cx="3" cy="29" r="1.1" fill="hsl(0 18% 16%)" opacity="0.9" />
          <circle cx="3" cy="29" r="1.8" fill="hsl(0 18% 16%)" opacity="0.18" />
        </svg>
      </div>
    </>
  );
};

export default InkCursor;
