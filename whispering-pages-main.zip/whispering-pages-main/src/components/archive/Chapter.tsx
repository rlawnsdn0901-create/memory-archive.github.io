import { motion } from "framer-motion";

interface ChapterProps {
  number: number;
  title?: string;
  subtitle?: string;
}

/**
 * "Chapter 001" style heading — a quiet preface above each section.
 */
const Chapter = ({ number, title, subtitle }: ChapterProps) => {
  const padded = String(number).padStart(3, "0");
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
      className="mx-auto mb-10 flex flex-col items-center gap-3 text-center"
    >
      <div className="flex items-center gap-3">
        <span className="h-px w-10 bg-ink-soft/40" />
        <span className="font-serif-soft text-[10px] tracking-[0.5em] text-ink-soft uppercase">
          Chapter&nbsp;{padded}
        </span>
        <span className="h-px w-10 bg-ink-soft/40" />
      </div>
      {title && (
        <p className="font-serif-soft text-sm italic text-ink-soft">{title}</p>
      )}
      {subtitle && (
        <p className="max-w-md font-body text-sm text-ink-soft/80">{subtitle}</p>
      )}
    </motion.div>
  );
};

export default Chapter;
