import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { folders, type ArchiveItem, type Category } from "@/data/archive";
import moviesImg from "@/assets/poster-movies.jpg";
import dramasImg from "@/assets/poster-dramas.jpg";
import novelsImg from "@/assets/poster-novels.jpg";
import WorkDetailModal from "./WorkDetailModal";
import CountUp from "./CountUp";
import { loadMemories, type Memory } from "@/lib/memoryStore";

const posterMap: Record<Category, string> = {
  movie: moviesImg,
  drama: dramasImg,
  novel: novelsImg,
};

// Slight, organic random-feeling rotations per card
const tilts = ["tilt-tiny-1", "tilt-tiny-2", "tilt-tiny-3"];

const PAGE_SIZE = 8;

type SortKey = "recent" | "name" | "year";

const FolderShelf = () => {
  const [openId, setOpenId] = useState<Category | null>(null);
  const [selected, setSelected] = useState<{ item: ArchiveItem; category: Category } | null>(null);
  const [memories, setMemories] = useState<Memory[]>([]);
  const [page, setPage] = useState(0);
  const [sortKey, setSortKey] = useState<SortKey>("recent");

  useEffect(() => {
    setMemories(loadMemories());
    const refresh = () => setMemories(loadMemories());
    window.addEventListener("ql:memories-changed", refresh);

    const onOpenFolder = (e: Event) => {
      const detail = (e as CustomEvent<{ category: Category }>).detail;
      if (detail?.category) {
        setOpenId(detail.category);
        setPage(0);
      }
    };
    window.addEventListener("ql:open-folder", onOpenFolder);
    return () => {
      window.removeEventListener("ql:memories-changed", refresh);
      window.removeEventListener("ql:open-folder", onOpenFolder);
    };
  }, []);

  // Reset page when switching folders
  useEffect(() => {
    setPage(0);
  }, [openId]);

  // Merge seed items with user-recorded memories per category.
  // 같은 제목은 작품 1개로 합친다 — 기록만 누적, 카드는 절대 중복되지 않음.
  const combinedItemsFor = (cat: Category): ArchiveItem[] => {
    const seed = folders.find((f) => f.id === cat)?.items ?? [];
    const seedByTitle = new Map<string, ArchiveItem>();
    seed.forEach((s) => seedByTitle.set(s.title.trim().toLowerCase(), s));

    // 카테고리별 메모리를 제목 기준으로 가장 최근 항목만 보관
    const grouped = new Map<string, Memory>();
    memories
      .filter((m) => m.category === cat)
      .forEach((m) => {
        const key = m.title.trim().toLowerCase();
        const existing = grouped.get(key);
        if (!existing || new Date(m.date).getTime() > new Date(existing.date).getTime()) {
          grouped.set(key, m);
        }
      });

    // 1) seed 항목은 항상 seed 형태 유지 (사용자가 같은 제목으로 기록을 더해도 카드 중복 X)
    const seedItems: ArchiveItem[] = seed.map((s) => s);

    // 2) seed에 없는 제목만 user item으로 새로 추가
    const userItems: ArchiveItem[] = Array.from(grouped.values())
      .filter((m) => !seedByTitle.has(m.title.trim().toLowerCase()))
      .map((m) => ({
        title: m.title,
        original: m.originalTitle,
        year: m.year,
        // 카드에 보이는 한 줄 — AI가 정리해 둔 작품 설명 우선, 없으면 안내 문구
        note: m.description || "조용히 기억으로 남겨둔 한 편.",
        // 상세에서 보이는 "처음 새겨둔 한 줄" — 가장 최근 기록 본문에서 발췌
        record: m.body
          ? m.body.length > 120
            ? m.body.slice(0, 120) + "…"
            : m.body
          : "이 작품에 대한 첫 줄을 적어보세요.",
      }));

    return [...userItems, ...seedItems];
  };

  const openItems = useMemo(() => {
    if (!openId) return [];
    const base = combinedItemsFor(openId);
    // 정렬 — 색인 정리 느낌으로
    const list = [...base];
    if (sortKey === "name") {
      list.sort((a, b) => a.title.localeCompare(b.title, "ko"));
    } else if (sortKey === "year") {
      // 최근 년도가 위로 (없는 항목은 뒤로)
      list.sort((a, b) => {
        const ya = a.year ? parseInt(a.year, 10) : -Infinity;
        const yb = b.year ? parseInt(b.year, 10) : -Infinity;
        return yb - ya;
      });
    }
    // "recent"는 combinedItemsFor가 이미 사용자 기록을 위로 두는 순서를 유지함
    return list;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openId, memories, sortKey]);

  const totalPages = Math.max(1, Math.ceil(openItems.length / PAGE_SIZE));
  const pageItems = openItems.slice(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE);

  // 정렬을 바꾸면 첫 페이지로 돌아가기
  useEffect(() => {
    setPage(0);
  }, [sortKey]);

  const handleAddWork = () => {
    document.getElementById("hero")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section id="folders" className="relative px-6 py-28 md:py-36">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
          className="mb-16 text-center"
        >
          <p className="mb-4 font-serif-soft text-xs tracking-[0.4em] text-ink-soft uppercase">
            — the folders —
          </p>
          <h2 className="font-display text-4xl text-ink md:text-5xl">
            <span aria-hidden className="font-display text-wood/40">"</span>
            기억의 <span className="font-light text-wood">서가</span>
            <span aria-hidden className="font-display text-wood/40">"</span>
          </h2>
          <p className="mx-auto mt-5 max-w-md font-body text-base text-ink-soft">
            그날의 장면들을 천천히 들여다보세요.
          </p>
          <div className="ink-divider mt-8" />
        </motion.div>

        {/* Folder tabs */}
        <div className="grid gap-8 md:grid-cols-3 md:gap-6">
          {folders.map((folder, i) => {
            const isOpen = openId === folder.id;
            const count = combinedItemsFor(folder.id).length;
            return (
              <motion.button
                key={folder.id}
                onClick={() => {
                  // Toggle: clicking the open folder closes it
                  if (isOpen) {
                    setOpenId(null);
                    return;
                  }
                  setOpenId(folder.id);
                  setPage(0);
                  setTimeout(() => {
                    document
                      .getElementById("folder-contents")
                      ?.scrollIntoView({ behavior: "smooth", block: "start" });
                  }, 120);
                }}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{
                  duration: 1.4,
                  delay: i * 0.18,
                  ease: [0.22, 1, 0.36, 1],
                }}
                data-cursor="hover"
                className={`group relative text-left transition-transform duration-700 ${tilts[i % tilts.length]}`}
                aria-expanded={isOpen}
              >
                <div className="absolute -top-3 left-6 h-6 w-24 rounded-t-md bg-wood/80 shadow-paper" />
                <div className="absolute -top-3 left-7 h-6 w-22 rounded-t-md bg-paper-aged" />

                <div className="paper-stack relative">
                  <div className="paper-card lift-soft relative overflow-hidden p-6">
                    {/* Number — the primary focal point */}
                    <div className="flex items-end justify-between border-b border-ink/10 pb-4">
                      <div>
                        <p className="font-mono-soft text-[10px] tracking-[0.18em] text-wood uppercase">
                          N° {String(i + 1).padStart(2, "0")}
                        </p>
                        <h3 className="mt-1 font-display text-2xl text-ink">{folder.korean}</h3>
                        <span className="font-mono-soft text-[10px] uppercase text-ink-soft/70">
                          {folder.english}
                        </span>
                      </div>
                      <div className="text-right leading-none">
                        <span className="block font-display text-6xl text-wood-deep tabular-nums md:text-7xl">
                          <CountUp end={count} />
                        </span>
                        <span className="mt-2 block font-mono-soft text-[10px] tracking-[0.2em] text-ink-soft uppercase">
                          편의 기록
                        </span>
                      </div>
                    </div>

                    {/* Smaller, secondary image */}
                    <div className="photo-frame mt-4 mx-auto aspect-[4/3] max-w-[120px] overflow-hidden opacity-90">
                      <img
                        src={posterMap[folder.id]}
                        alt={`${folder.korean} 폴더 표지`}
                        loading="lazy"
                        width={512}
                        height={384}
                        className="h-full w-full object-cover photo-vintage transition-transform duration-[1400ms] ease-out group-hover:scale-[1.02]"
                      />
                    </div>
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>

        {/* Opened folder contents */}
        <AnimatePresence mode="wait">
          {openId && (
            <motion.div
              key={openId}
              id="folder-contents"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 16 }}
              transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
              className="mt-16"
            >
              <FolderContents
                items={pageItems}
                korean={folders.find((f) => f.id === openId)!.korean}
                page={page}
                totalPages={totalPages}
                onPageChange={setPage}
                onSelect={(item) => setSelected({ item, category: openId })}
                onAddWork={handleAddWork}
                sortKey={sortKey}
                onSortChange={setSortKey}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <WorkDetailModal
        open={!!selected}
        onClose={() => setSelected(null)}
        item={selected?.item ?? null}
        category={selected?.category ?? null}
      />
    </section>
  );
};

const sortLabels: Record<SortKey, string> = {
  recent: "최신순",
  name: "이름순",
  year: "년도순",
};

const FolderContents = ({
  items,
  korean,
  page,
  totalPages,
  onPageChange,
  onSelect,
  onAddWork,
  sortKey,
  onSortChange,
}: {
  items: ArchiveItem[];
  korean: string;
  page: number;
  totalPages: number;
  onPageChange: (p: number) => void;
  onSelect: (item: ArchiveItem) => void;
  onAddWork: () => void;
  sortKey: SortKey;
  onSortChange: (k: SortKey) => void;
}) => (
  <div className="paper-card relative p-8 md:p-12">
    <div className="mb-6 flex items-center gap-4">
      <div className="h-px flex-1 bg-ink/15" />
      <span className="font-serif-soft text-[11px] tracking-[0.4em] text-ink-soft uppercase">
        — {korean} 색인 —
      </span>
      <div className="h-px flex-1 bg-ink/15" />
    </div>

    {/* 색인 정렬 — 종이 라벨 느낌 */}
    <div className="mb-8 flex items-center justify-end gap-3 border-b border-dashed border-ink/15 pb-3">
      <span className="font-serif-soft text-[10px] italic tracking-[0.25em] text-ink-soft/70 uppercase">
        정리 순서
      </span>
      <div className="flex items-center gap-1">
        {(Object.keys(sortLabels) as SortKey[]).map((k, i) => {
          const active = k === sortKey;
          return (
            <span key={k} className="flex items-center">
              {i > 0 && (
                <span className="mx-1 font-serif-soft text-[10px] text-ink-soft/40">·</span>
              )}
              <button
                type="button"
                onClick={() => onSortChange(k)}
                data-cursor="hover"
                className={`font-serif-soft text-[11px] italic tracking-[0.15em] transition-colors ${
                  active
                    ? "text-wood-deep underline decoration-wood/40 decoration-dotted underline-offset-4"
                    : "text-ink-soft/60 hover:text-wood"
                }`}
              >
                {sortLabels[k]}
              </button>
            </span>
          );
        })}
      </div>
    </div>

    <ul className="grid gap-x-10 gap-y-4 md:grid-cols-2">
      {items.map((it, idx) => (
        <motion.li
          key={`${it.title}-${idx}`}
          initial={{ opacity: 0, x: -8 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.9, delay: idx * 0.05, ease: [0.22, 1, 0.36, 1] }}
          className="border-b border-dashed border-ink/15 pb-3"
        >
          <button
            type="button"
            onClick={() => onSelect(it)}
            data-cursor="hover"
            className="group flex w-full items-baseline gap-4 text-left"
          >
            <span className="font-serif-soft text-[10px] tracking-[0.2em] text-ink-soft/60">
              {String(page * 8 + idx + 1).padStart(2, "0")}
            </span>
            <div className="flex-1">
              <p className="font-display text-lg text-ink transition-colors group-hover:text-wood">
                {it.title}
              </p>
              {it.original && (
                <p className="font-serif-soft text-xs italic text-ink-soft/70">
                  {it.original}
                  {it.year && <span> · {it.year}</span>}
                </p>
              )}
            </div>
          </button>
        </motion.li>
      ))}
    </ul>

    {totalPages > 1 && (
      <div className="mt-10 flex items-center justify-center gap-6">
        <button
          type="button"
          onClick={() => onPageChange(Math.max(0, page - 1))}
          disabled={page === 0}
          data-cursor="hover"
          className="font-serif-soft text-xs italic tracking-[0.25em] text-ink-soft uppercase transition-colors hover:text-wood disabled:cursor-default disabled:opacity-30"
        >
          ← 이전 장
        </button>

        <div className="flex items-center gap-2">
          {Array.from({ length: totalPages }).map((_, i) => {
            const active = i === page;
            return (
              <button
                key={i}
                type="button"
                onClick={() => onPageChange(i)}
                data-cursor="hover"
                aria-label={`${i + 1} 페이지`}
                className={`font-serif-soft text-sm italic transition-colors ${
                  active ? "text-wood-deep" : "text-ink-soft/50 hover:text-wood"
                }`}
              >
                {active ? `· ${i + 1} ·` : i + 1}
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={() => onPageChange(Math.min(totalPages - 1, page + 1))}
          disabled={page >= totalPages - 1}
          data-cursor="hover"
          className="font-serif-soft text-xs italic tracking-[0.25em] text-ink-soft uppercase transition-colors hover:text-wood disabled:cursor-default disabled:opacity-30"
        >
          다음 장 →
        </button>
      </div>
    )}

    <div className="mt-10 flex justify-center border-t border-dashed border-ink/15 pt-8">
      <button
        type="button"
        onClick={onAddWork}
        data-cursor="hover"
        className="flex items-center gap-2 border border-dashed border-wood/40 bg-paper-warm/30 px-5 py-2.5 font-serif-soft text-xs italic tracking-[0.2em] text-wood uppercase transition-all duration-500 hover:bg-paper-warm/60"
      >
        + 이 서가에 작품 더하기
      </button>
    </div>
  </div>
);

export default FolderShelf;
