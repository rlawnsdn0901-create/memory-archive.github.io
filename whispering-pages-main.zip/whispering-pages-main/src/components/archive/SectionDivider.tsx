import { motion } from "framer-motion";

interface Props {
  text?: string;
}

const SectionDivider = ({ text }: Props) => (
  <motion.div
    initial={{ opacity: 0 }}
    whileInView={{ opacity: 1 }}
    viewport={{ once: true }}
    transition={{ duration: 2 }}
    className="mx-auto flex max-w-xs flex-col items-center gap-4 py-12"
  >
    <div className="h-px w-full bg-gradient-to-r from-transparent via-ink-soft/30 to-transparent" />
    {text && (
      <span className="font-serif-soft text-xs italic tracking-[0.3em] text-ink-soft uppercase">
        {text}
      </span>
    )}
    <div className="h-1.5 w-1.5 rotate-45 bg-wood/40" />
  </motion.div>
);

export default SectionDivider;
