import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import { Plus } from "lucide-react";
import {
  loadCollections,
  addCollection,
  addWorkToCollection,
  updateWorkInCollection,
  removeWorkFromCollection,
  updateCollectionExcerpt,
  loadMemories,
  type Collection,
  type Memory,
  type SampleWork,
} from "@/lib/memoryStore";
import { toast } from "sonner";

const tilts = ["tilt-l-sm", "tilt-r-sm", "tilt-l", "tilt-r-sm"];

type Entry = { title: string; line: string; date?: string; sampleIndex?: number };

const Collections = () => {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [memories, setMemories] = useState<Memory[]>([]);
  const [openId, setOpenId] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [addingWorkTo, setAddingWorkTo] = useState<string | null>(null);
  const [workTitle, setWorkTitle] = useState("");
  const [workLine, setWorkLine] = useState("");
  const [editingWork, setEditingWork] = useState<{ colId: string; idx: number } | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editLine, setEditLine] = useState("");

  useEffect(() => {
    setCollections(loadCollections());
    setMemories(loadMemories());

    const refresh = () => {
      setCollections(loadCollections());
      setMemories(loadMemories());
    };
    window.addEventListener("ql:collections-changed", refresh);
    window.addEventListener("ql:memories-changed", refresh);
    return () => {
      window.removeEventListener("ql:collections-changed", refresh);
      window.removeEventListener("ql:memories-changed", refresh);
    };
  }, []);

  const entriesFor = (col: Collection): Entry[] => {
    const fromMemories: Entry[] =
      col.memoryIds.length > 0
        ? memories
            .filter((m) => col.memoryIds.includes(m.id))
            .map((m) => ({
              title: m.title,
              line: m.body
                ? m.body.length > 80
                  ? m.body.slice(0, 80) + "…"
                  : m.body
                : "아직 이 작품에 대한 기록은 없어요.",
              date: m.date,
            }))
        : [];
    const fromSamples: Entry[] = (col.samples ?? []).map((s, i) => ({
      title: s.title,
      line: s.line,
      sampleIndex: i,
    }));
    return [...fromMemories, ...fromSamples];
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const t = newTitle.trim();
    if (!t) return;
    addCollection(t);
    setNewTitle("");
    setAdding(false);
    toast("새 노트를 책상 위에 올려두었어요.");
  };

  const handleAddWork = (e: React.FormEvent, colId: string) => {
    e.preventDefault();
    const t = workTitle.trim();
    if (!t) return;
    const work: SampleWork = {
      title: t,
      line: workLine.trim() || "아직 이 작품에 대한 기록은 없어요.",
    };
    addWorkToCollection(colId, work);
    setWorkTitle("");
    setWorkLine("");
    setAddingWorkTo(null);
    toast("이 노트에 작품을 끼워두었어요.");
  };

  const startEditWork = (colId: string, idx: number, sample: SampleWork) => {
    setEditingWork({ colId, idx });
    setEditTitle(sample.title);
    setEditLine(sample.line);
  };

  const handleSaveEditWork = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingWork) return;
    updateWorkInCollection(editingWork.colId, editingWork.idx, {
      title: editTitle.trim() || "이름 없는 기억",
      line: editLine.trim() || "아직 이 작품에 대한 기록은 없어요.",
    });
    setEditingWork(null);
    toast("이 페이지를 다시 정리해두었어요.");
  };

  const handleRemoveWork = (colId: string, idx: number) => {
    removeWorkFromCollection(colId, idx);
    toast("이 작품은 노트에서 빼두었어요.");
  };

  return (
    <section className="relative px-6 py-28 md:py-36">
      <div className="mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
          className="mb-16 text-center"
        >
          <p className="mb-4 font-serif-soft text-xs tracking-[0.4em] text-ink-soft uppercase">
            — notes & collections —
          </p>
          <h2 className="font-display text-4xl text-ink md:text-5xl">
            <span aria-hidden className="font-display text-wood/40">"</span>
            묶어둔 <span className="font-light text-wood">노트들</span>
            <span aria-hidden className="font-display text-wood/40">"</span>
          </h2>
          <p className="mx-auto mt-5 max-w-md font-body text-base text-ink-soft">
            계절과 기분, 시간으로 묶인 기억들을 천천히 꺼내보세요.
          </p>
          <div className="ink-divider mt-8" />
        </motion.div>

        <div className="grid gap-12 md:grid-cols-2">
          {collections.map((col, i) => {
            const isOpen = openId === col.id;
            const inside = entriesFor(col);
            const isAddingWork = addingWorkTo === col.id;
            return (
              <motion.div
                key={col.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{
                  duration: 1.4,
                  delay: i * 0.16,
                  ease: [0.22, 1, 0.36, 1],
                }}
                className="relative"
              >
                {/* Push pin */}
                <span className="push-pin left-1/2 -top-2 -translate-x-1/2" />

                {/* Stacked paper effect */}
                <div className="absolute inset-0 paper-texture translate-x-2 translate-y-2 opacity-60" />
                <div className="absolute inset-0 paper-texture translate-x-1 translate-y-1 opacity-80" />

                <article
                  className={`paper-card lift-soft relative p-8 pt-10 md:p-10 md:pt-12 ${tilts[i % tilts.length]}`}
                >
                  {/* Header — clickable toggle (div, to allow nested inputs below) */}
                  <div
                    role="button"
                    tabIndex={0}
                    onClick={() => setOpenId(isOpen ? null : col.id)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        setOpenId(isOpen ? null : col.id);
                      }
                    }}
                    data-cursor="hover"
                    aria-expanded={isOpen}
                    className="block w-full cursor-pointer text-left"
                  >
                    <div className="mb-5 flex items-center justify-between">
                      <span className="font-serif-soft text-[11px] tracking-[0.3em] text-wood uppercase">
                        № {String(i + 1).padStart(2, "0")} · {col.tag}
                      </span>
                      <span className="font-display text-2xl italic text-ink-soft">
                        {inside.length}
                      </span>
                    </div>

                    <h3 className="font-display text-3xl leading-tight text-ink">
                      {col.title}
                    </h3>
                  </div>

                  {/* Editable one-line description — outside the toggle */}
                  <textarea
                    value={col.excerpt}
                    onChange={(e) => updateCollectionExcerpt(col.id, e.target.value)}
                    placeholder="이 노트에 대한 한 줄 설명을 적어보세요"
                    rows={2}
                    className="mt-5 w-full resize-none bg-transparent font-body text-base leading-relaxed text-ink-soft placeholder:italic placeholder:text-ink-soft/50 focus:outline-none"
                  />

                  <div
                    role="button"
                    tabIndex={0}
                    onClick={() => setOpenId(isOpen ? null : col.id)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        setOpenId(isOpen ? null : col.id);
                      }
                    }}
                    data-cursor="hover"
                    className="mt-8 flex w-full items-center gap-3 cursor-pointer"
                  >
                    <div className="h-px flex-1 bg-ink/15" />
                    <span className="font-serif-soft text-xs italic text-ink-soft transition-colors">
                      {isOpen ? "덮어두기" : "펼쳐보기"}
                    </span>
                  </div>

                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        key="contents"
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
                        className="overflow-hidden"
                      >
                        <ul className="mt-5 space-y-3 border-t border-dashed border-ink/15 pt-5">
                          {inside.length === 0 ? (
                            <li className="font-serif-soft text-sm italic text-ink-soft/70">
                              아직 이 노트에 꽂아둔 기록이 없어요.
                            </li>
                          ) : (
                            inside.map((entry, idx) => {
                              const isEditing =
                                entry.sampleIndex !== undefined &&
                                editingWork?.colId === col.id &&
                                editingWork?.idx === entry.sampleIndex;
                              return (
                                <li
                                  key={`${entry.title}-${idx}`}
                                  className="flex items-baseline gap-3 border-b border-dashed border-ink/10 pb-2 last:border-0"
                                >
                                  <span className="font-serif-soft text-[10px] tracking-[0.2em] text-ink-soft/60">
                                    {String(idx + 1).padStart(2, "0")}
                                  </span>
                                  <div className="flex-1">
                                    {isEditing ? (
                                      <form onSubmit={handleSaveEditWork} className="space-y-2">
                                        <input
                                          autoFocus
                                          value={editTitle}
                                          onChange={(e) => setEditTitle(e.target.value)}
                                          placeholder="작품 제목"
                                          className="w-full border-b border-ink/20 bg-transparent pb-1 font-display text-base text-ink focus:border-wood focus:outline-none"
                                        />
                                        <input
                                          value={editLine}
                                          onChange={(e) => setEditLine(e.target.value)}
                                          placeholder="짧은 한 줄 기록"
                                          className="w-full border-b border-ink/20 bg-transparent pb-1 font-serif-soft text-sm italic text-ink focus:border-wood focus:outline-none"
                                        />
                                        <div className="flex items-center gap-3 pt-1">
                                          <button
                                            type="submit"
                                            className="border border-wood/40 px-3 py-1 font-serif-soft text-xs italic tracking-[0.15em] text-wood uppercase hover:bg-wood hover:text-paper transition-all duration-500"
                                          >
                                            저장
                                          </button>
                                          <button
                                            type="button"
                                            onClick={() => setEditingWork(null)}
                                            className="font-serif-soft text-xs italic text-ink-soft hover:text-wood"
                                          >
                                            취소
                                          </button>
                                        </div>
                                      </form>
                                    ) : (
                                      <div className="flex items-start justify-between gap-3">
                                        <div className="flex-1">
                                          <p className="font-display text-base text-ink">
                                            {entry.title}
                                          </p>
                                          <p className="font-serif-soft text-sm italic text-ink-soft text-balance">
                                            {entry.line}
                                          </p>
                                        </div>
                                        {entry.sampleIndex !== undefined && (
                                          <div className="flex shrink-0 items-center gap-2 pt-1">
                                            <button
                                              type="button"
                                              onClick={() =>
                                                startEditWork(
                                                  col.id,
                                                  entry.sampleIndex!,
                                                  (col.samples ?? [])[entry.sampleIndex!]
                                                )
                                              }
                                              data-cursor="hover"
                                              className="font-serif-soft text-[10px] italic tracking-[0.15em] text-wood hover:text-wood-deep"
                                            >
                                              고치기
                                            </button>
                                            <button
                                              type="button"
                                              onClick={() => handleRemoveWork(col.id, entry.sampleIndex!)}
                                              data-cursor="hover"
                                              className="font-serif-soft text-[10px] italic tracking-[0.15em] text-ink-soft/70 hover:text-destructive"
                                            >
                                              빼두기
                                            </button>
                                          </div>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                </li>
                              );
                            })
                          )}
                        </ul>

                        {/* Add a work to this note */}
                        <div className="mt-5">
                          {!isAddingWork ? (
                            <button
                              type="button"
                              onClick={() => setAddingWorkTo(col.id)}
                              data-cursor="hover"
                              className="flex items-center gap-2 border border-dashed border-wood/40 bg-paper-warm/30 px-4 py-2 font-serif-soft text-xs italic tracking-[0.2em] text-wood uppercase transition-all duration-500 hover:bg-paper-warm/60"
                            >
                              <Plus className="h-3 w-3" strokeWidth={1.4} />
                              작품 더하기
                            </button>
                          ) : (
                            <form
                              onSubmit={(e) => handleAddWork(e, col.id)}
                              className="space-y-3 border-t border-dashed border-ink/15 pt-4"
                            >
                              <input
                                autoFocus
                                value={workTitle}
                                onChange={(e) => setWorkTitle(e.target.value)}
                                placeholder="작품 제목"
                                className="w-full border-b border-ink/20 bg-transparent pb-1.5 font-display text-base text-ink placeholder:font-serif-soft placeholder:text-sm placeholder:italic placeholder:text-ink-soft/50 focus:border-wood focus:outline-none"
                              />
                              <input
                                value={workLine}
                                onChange={(e) => setWorkLine(e.target.value)}
                                placeholder="짧은 한 줄 기록"
                                className="w-full border-b border-ink/20 bg-transparent pb-1.5 font-serif-soft text-sm italic text-ink placeholder:text-ink-soft/50 focus:border-wood focus:outline-none"
                              />
                              <div className="flex items-center gap-3">
                                <button
                                  type="submit"
                                  className="border border-wood/40 px-4 py-1.5 font-serif-soft text-xs italic tracking-[0.2em] text-wood uppercase hover:bg-wood hover:text-paper transition-all duration-500"
                                >
                                  끼워두기
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setAddingWorkTo(null);
                                    setWorkTitle("");
                                    setWorkLine("");
                                  }}
                                  className="font-serif-soft text-xs italic text-ink-soft hover:text-wood"
                                >
                                  취소
                                </button>
                              </div>
                            </form>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </article>
              </motion.div>
            );
          })}

          {/* Add a new note folder */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
            className="relative md:col-span-2"
          >
            {!adding ? (
              <button
                type="button"
                onClick={() => setAdding(true)}
                data-cursor="hover"
                className="mx-auto flex items-center gap-3 border border-dashed border-wood/40 bg-paper-warm/30 px-6 py-3 font-serif-soft text-sm italic tracking-[0.2em] text-wood transition-all duration-500 hover:bg-paper-warm/60"
              >
                <Plus className="h-3.5 w-3.5" strokeWidth={1.4} />
                새 노트 묶음 더하기
              </button>
            ) : (
              <form
                onSubmit={handleAdd}
                className="paper-card mx-auto flex max-w-md items-center gap-3 p-5"
              >
                <input
                  autoFocus
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="새 노트의 제목"
                  className="flex-1 border-b border-ink/20 bg-transparent pb-2 font-display text-lg text-ink placeholder:font-serif-soft placeholder:text-sm placeholder:italic placeholder:text-ink-soft/50 focus:border-wood focus:outline-none"
                />
                <button
                  type="submit"
                  className="border border-wood/40 px-4 py-1.5 font-serif-soft text-xs italic tracking-[0.2em] text-wood uppercase hover:bg-wood hover:text-paper transition-all duration-500"
                >
                  더하기
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAdding(false);
                    setNewTitle("");
                  }}
                  className="font-serif-soft text-xs italic text-ink-soft hover:text-wood"
                >
                  취소
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Collections;
