import { motion } from "framer-motion";
import CountUp from "./CountUp";
import { movies, dramas, novels } from "@/data/archive";
import moviesImg from "@/assets/cat-movies.jpg";
import dramasImg from "@/assets/cat-dramas.jpg";
import novelsImg from "@/assets/cat-novels.jpg";

const cats = [
  {
    name: "Movies",
    korean: "영화",
    items: movies,
    image: moviesImg,
    tilt: "tilt-l",
    italic: "the silver screen",
  },
  {
    name: "Dramas",
    korean: "드라마",
    items: dramas,
    image: dramasImg,
    tilt: "tilt-r-sm",
    italic: "long evenings",
  },
  {
    name: "Novels",
    korean: "소설",
    items: novels,
    image: novelsImg,
    tilt: "tilt-r",
    italic: "underlined pages",
  },
];

const Categories = () => {
  return (
    <section className="relative px-6 py-32 md:py-40">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
          className="mb-20 text-center"
        >
          <p className="mb-4 font-serif-soft text-xs tracking-[0.4em] text-ink-soft uppercase">
            — the shelves —
          </p>
          <h2 className="font-display text-4xl text-ink md:text-5xl">
            서가에 놓인 <em className="italic font-light text-wood">기억들</em>
          </h2>
          <div className="ink-divider mt-8" />
        </motion.div>

        <div className="grid gap-12 md:grid-cols-3 md:gap-8">
          {cats.map((cat, i) => (
            <motion.article
              key={cat.name}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{
                duration: 1.6,
                delay: i * 0.25,
                ease: [0.22, 1, 0.36, 1],
              }}
              className={`paper-card lift-soft p-5 ${cat.tilt}`}
            >
              <div className="photo-frame mb-5 aspect-[4/5] overflow-hidden">
                <img
                  src={cat.image}
                  alt={`${cat.korean} 카테고리`}
                  loading="lazy"
                  width={1024}
                  height={1024}
                  className="h-full w-full object-cover photo-vintage"
                />
              </div>

              <div className="flex items-baseline justify-between">
                <h3 className="font-display text-2xl text-ink">{cat.korean}</h3>
                <span className="font-serif-soft text-xs italic text-ink-soft">
                  {cat.italic}
                </span>
              </div>

              <div className="mt-3 flex items-end gap-3">
                <span className="font-display text-6xl leading-none text-wood">
                  <CountUp end={cat.items.length} />
                </span>
                <span className="mb-2 font-serif-soft text-sm text-ink-soft">
                  편의 기록
                </span>
              </div>

              <ul className="mt-6 space-y-1.5 border-t border-ink/10 pt-4">
                {cat.items.slice(0, 3).map((it) => (
                  <li
                    key={it.title}
                    className="font-serif-soft text-sm text-ink-soft"
                  >
                    · {it.title}
                  </li>
                ))}
                <li className="pt-1 font-serif-soft text-xs italic text-ink-soft/70">
                  외 {cat.items.length - 3}편…
                </li>
              </ul>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;
