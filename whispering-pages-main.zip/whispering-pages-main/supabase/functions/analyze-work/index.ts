// Analyze a work (movie/drama/novel) using Lovable AI
// Returns: { title, category, description, emotionTags }

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { query } = await req.json();
    if (!query || typeof query !== "string" || query.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: "검색어를 입력해 주세요." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const systemPrompt = `당신은 영화, 드라마, 소설을 깊이 이해하는 조용한 사서입니다.
사용자가 작품 제목을 검색하면, 두 가지 설명을 함께 정리합니다.
1) description: 검색 결과 화면에 보여줄 2~3문장의 충분하고 따뜻한 작품 소개. 분위기·핵심 내용·감정적 특징을 자연스럽게 담아주세요.
2) shortDescription: 폴더에 꽂아둘 한 줄 요약. 25자 이내, 마침표 없이, 정보 나열 금지, 분위기·여운만. (예: '조용히 감정이 쌓여가는 이야기', '짧은 대화 속에 오래 남는 여운')
반드시 한국어로 답하고, 한글 제목·영문 원제·발표 연도(또는 작가)도 함께 정리합니다.
작품을 모르면 가장 가까운 작품을 추측해 주세요.`;

    const tools = [
      {
        type: "function",
        function: {
          name: "describe_work",
          description: "작품을 분석하여 카테고리, 긴 소개, 한 줄 요약, 감정 태그를 반환합니다.",
          parameters: {
            type: "object",
            properties: {
              title: { type: "string", description: "작품의 한국어 제목" },
              originalTitle: { type: "string", description: "원제 (있다면)" },
              category: { type: "string", enum: ["movie", "drama", "novel"], description: "영화/드라마/소설 중 하나" },
              year: { type: "string", description: "발표 연도 또는 작가" },
              description: {
                type: "string",
                description: "검색 결과 화면용 2~3문장의 따뜻하고 충분한 작품 소개. 분위기·핵심 내용·감정적 특징을 자연스럽게 담는다.",
              },
              shortDescription: {
                type: "string",
                description: "폴더 카드용 한 줄 요약. 25자 이내, 마침표 없이, 정보 나열 금지, 분위기·여운만. description과 절대 같으면 안 된다.",
              },
              emotionTags: {
                type: "array",
                items: { type: "string" },
                description: "이 작품을 떠올릴 때 남는 감정 단어 4~6개 (예: 잔잔함, 쓸쓸함, 첫사랑, 그리움)",
              },
              gentleLine: {
                type: "string",
                description: "사용자에게 기록을 권하는 한 줄 (예: '이 기억을 당신의 방식으로 남겨보세요.')",
              },
            },
            required: ["title", "category", "description", "shortDescription", "emotionTags", "gentleLine"],
            additionalProperties: false,
          },
        },
      },
    ];

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `다음 작품을 분석해 주세요: "${query}"` },
        ],
        tools,
        tool_choice: { type: "function", function: { name: "describe_work" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "잠시 너무 많이 찾아오셨어요. 한 호흡 두고 다시 시도해 주세요." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI 사용 크레딧이 모두 소진되었어요. 워크스페이스에서 충전이 필요합니다." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(
        JSON.stringify({ error: "작품을 불러오는 중 잠시 문제가 있었어요." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) {
      return new Response(
        JSON.stringify({ error: "이 작품을 찾지 못했어요." }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const parsed = JSON.parse(toolCall.function.arguments);
    return new Response(JSON.stringify(parsed), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("analyze-work error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
